/**
* NOTICE OF LICENSE
*
* This source file is subject to the MIT License (MIT)
* that is bundled with this package in the file LICENSE.md.
*
* @author mElements S.A.
* @copyright mElements S.A.
* @license   MIT License
**/
$(document).ready(function () {
    $('.payment-option-pbls').click(function () {
        $('.paynow-payment-option-pbls').slideDown();
    });
});